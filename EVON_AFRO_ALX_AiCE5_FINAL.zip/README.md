# EVON AFRO — ALX AiCE-5

Tableau de bord interactif de segmentation des clients automobiles, construit à partir du projet v0.dev fourni puis corrigé sans utiliser de crédits v0.dev.

## Contenu
- `index.html` : interface responsive et interactive.
- `data.js` : données historiques encodées pour les graphiques.
- `data.csv` : jeu de données source.
- `model.js` : modèle Gradient Boosting exécuté dans le navigateur.
- `metrics.json` : métriques, matrice de confusion et valeurs manquantes.
- `train_model.py` : script de reproduction de l'entraînement et de l'évaluation.
- `README.md` : instructions et limites.

## Données
Le CSV contient 8,068 clients et 11 colonnes. Les segments sont A, B, C et D. Le fichier ne contient pas les 2 627 nouveaux clients mentionnés dans le descriptif ALX. Aucun de ces nouveaux clients n'a donc été prédit par cette livraison.

## Modèle et évaluation
Algorithme : `GradientBoostingClassifier(random_state=42)`.

Validation : `StratifiedKFold(n_splits=5, shuffle=True, random_state=42)` avec prédictions hors-échantillon (`cross_val_predict`). Les prétraitements sont contenus dans le pipeline et sont donc ajustés à l'intérieur de chaque pli :
- catégorielles : imputation par modalité la plus fréquente puis one-hot encoding ;
- numériques : imputation par médiane ;
- colonne `ID` exclue des variables explicatives.

Résultats mesurés :
- Exactitude : **53.79 %**
- F1 macro : **52.54 %**
- Exactitude équilibrée : **52.85 %**
- Référence majoritaire : **28.11 %**

Les probabilités brutes affichées dans le simulateur ne sont pas calibrées. Elles constituent une indication, pas une certitude. Une validation sur des données du nouveau marché est nécessaire avant toute décision opérationnelle.

## Limites commerciales
Le dataset ne contient ni ventes, ni prix, ni marges, ni choix des produits P1 à P5. Les pistes commerciales du tableau de bord sont donc des hypothèses à tester et non des conclusions sur la performance réelle des produits.

## Ouvrir localement
Ouvre `index.html` dans un navigateur récent. Une connexion Internet est nécessaire pour charger Chart.js depuis jsDelivr.

## Publication sur Vercel depuis Android
1. Décompresse ce ZIP.
2. Connecte-toi à https://vercel.com.
3. Crée un nouveau projet et importe le dossier du site (ou son dépôt GitHub).
4. Pour ce site statique, aucun framework ni commande de build n'est nécessaire.
5. Déploie, puis teste sur ton téléphone : filtres, graphiques, simulateur et affichage mobile.
